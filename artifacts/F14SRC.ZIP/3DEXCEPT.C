#include "library.h"
#include "f15defs.h"
#include "world.h"
#include "sdata.h"
#include "armt.h"
#include "speech.h"
#include "event.h"


int IneffectiveHit;


//***************************************************************************
struct CloseObj *CheckTargetHit (long X, long Z, WEAPON *Wpn)
{
    return (NULL);
}


